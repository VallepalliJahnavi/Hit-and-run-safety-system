def simulate_dispatch(event, tracking_result):
    alert_text = f"Crash severity {event['severity']} at {event['location']}. Victim {event['victim_status']}. Vehicle {event['plate']}. Offender {'fled' if tracking_result['fled'] else 'did not flee'}. Movement path: {tracking_result['movement_path']}"
    return {
        "alert_text": alert_text,
        "priority": "High",
        "emergency_contact": "911"
    }
