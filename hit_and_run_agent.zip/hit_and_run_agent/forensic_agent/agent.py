def simulate_forensic(event):
    return {
        "video": "https://example.com/video123.mp4",
        "license_plate": event["plate"],
        "logs": f"Crash logged at {event['location']} with severity {event['severity']}."
    }
