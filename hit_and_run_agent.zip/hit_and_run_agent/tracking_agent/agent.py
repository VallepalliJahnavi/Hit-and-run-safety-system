import random

def simulate_tracking(event):
    lat, lon = map(float, event["location"].split(","))
    path = []
    # Simulate 5 movement steps
    for i in range(5):
        lat += random.uniform(0.0001, 0.0005)
        lon += random.uniform(0.0001, 0.0005)
        path.append([round(lat,6), round(lon,6)])
    
    fled = True  # Assume vehicle fled for simulation
    reason = "Vehicle moved more than 500 meters from crash site." if fled else "Vehicle did not flee."
    
    return {
        "initial_location": event["location"],
        "movement_path": path,
        "fled": fled,
        "reason": reason
    }
