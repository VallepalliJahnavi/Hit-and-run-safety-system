def simulate_impact(event):
    severity = event.get("severity", 1)
    action_required = True if severity >= 3 else False
    message = f"Crash severity {severity} detected. {'All sub-agents must be notified.' if action_required else 'No immediate action required.'}"
    return {
        "severity": severity,
        "action_required": action_required,
        "message": message
    }
