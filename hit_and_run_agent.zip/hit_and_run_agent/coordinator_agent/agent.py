from google.adk.agents import LlmAgent
from impact_agent.agent import simulate_impact
from tracking_agent.agent import simulate_tracking
from dispatch_agent.agent import simulate_dispatch
from forensic_agent.agent import simulate_forensic
from victim_care_agent.agent import simulate_victim_care
import json

coordinator_agent = LlmAgent(
    name="Coordinator",
    model="gemini-2.5-flash",
    instruction="Route events to all sub-agents and combine outputs.",
    sub_agents=[]
)

def run_with_tracking(event):
    impact_result = simulate_impact(event)
    tracking_result = simulate_tracking(event)
    dispatch_result = simulate_dispatch(event, tracking_result)
    forensic_result = simulate_forensic(event)
    victim_care_result = simulate_victim_care(event)

    combined = {
        "impact": impact_result,
        "tracking": tracking_result,
        "dispatch": dispatch_result,
        "forensic": forensic_result,
        "victim_care": victim_care_result
    }

    return combined
