from coordinator_agent.agent import run_with_tracking

# Input crash event
event = {
    "severity": 4,
    "location": "40.7128,-74.0060",
    "plate": "ABC1234",
    "victim_status": "unconscious"
}

result = run_with_tracking(event)

impact = result["impact"]
tracking = result["tracking"]
dispatch = result["dispatch"]
forensic = result["forensic"]
victim_care = result["victim_care"]

# Clean human-readable paragraph
paragraph = f"""
Crash severity {impact['severity']} detected. {impact['message']}

Offender Tracking:
- Started at {tracking['initial_location']}
- Movement path: {tracking['movement_path']}
- Fleeing from the scene: {"Yes" if tracking['fled'] else "No"}

Dispatch Alert:
{dispatch['alert_text']}

Forensics:
- Video collected: {forensic['video']}
- License plate: {forensic['license_plate']}
- Crash logs recorded

Victim Care:
- Instructions: {victim_care['first_aid']}
- Family notified: {victim_care['notification']}
- Call 911 immediately and confirmation sent.
"""

print(paragraph.strip())
