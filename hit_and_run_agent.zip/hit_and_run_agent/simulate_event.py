# main.py
from coordinator_agent.agent import coordinator_agent

event = {
    "severity": 4,
    "location": "40.7128,-74.0060",
    "plate": "ABC1234",
    "victim_status": "unconscious"
}

# Run the coordinator agent
response = coordinator_agent.run(f"A crash just happened: {event}")

# Print the response from all agents
print(response.text)
