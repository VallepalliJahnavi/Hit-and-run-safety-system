def simulate_victim_care(event):
    return {
        "first_aid": "Check airway, breathing, circulation. Keep victim still. Call 911 immediately.",
        "notification": f"Family notified of crash at {event['location']}."
    }
